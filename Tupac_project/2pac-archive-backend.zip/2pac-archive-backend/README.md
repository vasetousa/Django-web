# The 2Pac-Archive API

## Versions

-   Python 3.6.0
-   Django 2.1.5
-   MySQL 5.6

## Setting up

After creating a virtual environment with Python 3.6.0 and having Docker installed. Be sure to be in the root of the project and do the following:

Activate virtual environment:

```
. venv/bin/activate
```

Install requirements:

```
pip install -r requirements.txt
```

Start docker database (on first start it will create it):

```
docker-compose up
```

Generating the database tables:

```
./src/manage.py migrate
```

## Starting

Run docker database:

```
docker-compose up
```

Start the virtual environment in a new bash window:

```
. venv/bin/activate
```

Start Django:

```
./src/manage.py runserver
```
