from datetime import date

from tinymce.models import HTMLField

from django.db import models


class Interview(models.Model):
    default_date = date.fromisoformat('1990-01-01')

    title = models.CharField(max_length=300)
    description = HTMLField(verbose_name='Description', null=True, blank=True)
    interviewer = models.TextField(
        null=True, blank=True, help_text="Example: name1, name2, name3")
    interviewee = models.TextField(
        null=True, blank=True, help_text="Example: name1, name2, name3")
    youtube_video = models.CharField(
        max_length=20, null=True, blank=True, help_text="ID of the youtube video (not url)")
    date = models.DateField(default=default_date)
    interview_text = HTMLField(verbose_name='Interview text', null=True, blank=True)

    def __str__(self):
        return self.title


class TranscribedInterview(Interview):

    def __str__(self):
        return self.title


class VideoInterview(Interview):

    def __str__(self):
        return self.title


class RelatedTranscribedInterview(Interview):

    def __str__(self):
        return self.title


class RelatedVideoInterview(Interview):

    def __str__(self):
        return self.title


class AudioInterview(Interview):

    def __str__(self):
        return self.title


class RelatedAudioInterview(Interview):

    def __str__(self):
        return self.title
