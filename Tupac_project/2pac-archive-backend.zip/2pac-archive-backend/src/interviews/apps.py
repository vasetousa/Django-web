from django.apps import AppConfig


class InterviewsConfig(AppConfig):
    name = 'interviews'
