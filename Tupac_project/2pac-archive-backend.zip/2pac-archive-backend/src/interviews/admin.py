from django.contrib import admin

from rangefilter.filters import DateRangeFilter

from .models import TranscribedInterview, VideoInterview, RelatedTranscribedInterview, RelatedVideoInterview, AudioInterview, RelatedAudioInterview


class TranscribedInterviewAdmin(admin.ModelAdmin):
    list_display = ('title', 'date',)
    list_filter = (('date', DateRangeFilter),)


class VideoInterviewAdmin(admin.ModelAdmin):
    list_display = ('title', 'date',)
    list_filter = (('date', DateRangeFilter),)


class RelatedTranscribedInterviewAdmin(admin.ModelAdmin):
    list_display = ('title', 'date',)
    list_filter = (('date', DateRangeFilter),)


class RelatedVideoInterviewAdmin(admin.ModelAdmin):
    list_display = ('title', 'date',)
    list_filter = (('date', DateRangeFilter),)


class AudioInterviewAdmin(admin.ModelAdmin):
    list_display = ('title', 'date',)
    list_filter = (('date', DateRangeFilter),)


class RelatedAudioInterviewAdmin(admin.ModelAdmin):
    list_display = ('title', 'date',)
    list_filter = (('date', DateRangeFilter),)


admin.site.register(TranscribedInterview, TranscribedInterviewAdmin)
admin.site.register(VideoInterview, VideoInterviewAdmin)
admin.site.register(RelatedTranscribedInterview, RelatedTranscribedInterviewAdmin)
admin.site.register(RelatedVideoInterview, RelatedVideoInterviewAdmin)
admin.site.register(AudioInterview, AudioInterviewAdmin)
admin.site.register(RelatedAudioInterview, RelatedAudioInterviewAdmin)
