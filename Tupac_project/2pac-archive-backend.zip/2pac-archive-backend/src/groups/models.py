from django.db import models
from tinymce.models import HTMLField


class Group(models.Model):
    name = models.CharField(max_length=100)
    yearsActive = models.CharField(max_length=100)
    # members=affiliates
    
    

    def __str__(self):
        return self.name
