from django.db import models

from tinymce.models import HTMLField


class TypeOfSample(models.Model):
    name = models.CharField(max_length=100)

    class Meta:
        verbose_name_plural = "Types of samples"

    def __str__(self):
        return self.name


class Sample(models.Model):
    song = models.ForeignKey("songs.Song", on_delete=models.SET_NULL, null=True, blank=True)
    title = models.CharField(max_length=100)
    timeframe = models.CharField(max_length=100, blank=True)
    type_of_sample = models.ForeignKey(TypeOfSample, on_delete=models.SET_NULL, null=True)
    description = HTMLField(verbose_name='Description', null=True, blank=True)
    date_of_discovery = models.CharField(max_length=100, blank=True, help_text="format: MM/DD/YYYY")

    def __str__(self):
        return self.full_title

    @property
    def full_title(self):
        if self.song:
            return f'{self.song.title} ({self.title})'

        return self.title
