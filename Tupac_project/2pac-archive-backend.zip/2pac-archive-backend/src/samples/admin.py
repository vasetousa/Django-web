from django.contrib import admin

from .models import Sample, TypeOfSample


class SampleAdmin(admin.ModelAdmin):
    list_display = ('full_title',)
    search_fields = ['song__title', 'title',]
    ordering = ('song__title', 'title',)
    actions = ['duplicate_samples']

    def duplicate_samples(self, request, queryset):
        for sample in queryset:
            sample_dict = sample.__dict__
            del sample_dict['id']
            del sample_dict['_state']
            sample_dict['title'] = sample.title + "(1)"

            Sample.objects.create(**sample_dict)
    duplicate_samples.short_description = "Duplicate selected samples"


class TypeOfSampleAdmin(admin.ModelAdmin):
    list_display = ('name',)
    search_fields = ['name']
    ordering = ('name',)


admin.site.register(Sample, SampleAdmin)
admin.site.register(TypeOfSample, TypeOfSampleAdmin)
