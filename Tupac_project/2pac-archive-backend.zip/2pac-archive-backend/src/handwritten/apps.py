from django.apps import AppConfig


class HandwrittenConfig(AppConfig):
    name = 'handwritten'
