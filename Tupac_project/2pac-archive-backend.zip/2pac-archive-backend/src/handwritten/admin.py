from django.contrib import admin
from django.db import models

from .models import Tracklist, Lyrics, Other


class TracklistAdmin(admin.ModelAdmin):
    model = Tracklist


class LyricsAdmin(admin.ModelAdmin):
    model = Lyrics


class OtherAdmin(admin.ModelAdmin):
    model = Other


admin.site.register(Tracklist, TracklistAdmin)
admin.site.register(Lyrics, LyricsAdmin)
admin.site.register(Other, OtherAdmin)
