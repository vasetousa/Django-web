from django.db import models

from tinymce.models import HTMLField


class AbstractHandwritten(models.Model):
    title = models.CharField(max_length=100)
    text = HTMLField(verbose_name='Text', null=True, blank=True)
    date_of_creation = models.CharField(
        max_length=200, blank=True, help_text="format: MM/DD/YYYY multiple: MM/DD/YYYY - MM/DD/YYYY only year: YYYY")
    description = HTMLField(verbose_name='Description', null=True, blank=True)

    class Meta:
        abstract = True

    def __str__(self):
        return self.title


class Tracklist(AbstractHandwritten):
    def get_upload_path(instance, filename):
        return 'handwritten/tracklists/{0}-{1}'.format(instance.title, filename)

    photo = models.ImageField(null=True, blank=True, upload_to=get_upload_path)


class Lyrics(AbstractHandwritten):
    def get_upload_path(instance, filename):
        return 'handwritten/lyrics/{0}-{1}'.format(instance.title, filename)

    photo = models.ImageField(null=True, blank=True, upload_to=get_upload_path)

    class Meta:
        verbose_name_plural = "Lyrics"


class Other(AbstractHandwritten):
    def get_upload_path(instance, filename):
        return 'handwritten/other/{0}-{1}'.format(instance.title, filename)

    photo = models.ImageField(null=True, blank=True, upload_to=get_upload_path)
