from django.apps import AppConfig


class AffiliatesConfig(AppConfig):
    name = 'affiliates'
