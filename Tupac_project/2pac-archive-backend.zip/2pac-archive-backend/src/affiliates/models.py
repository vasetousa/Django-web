from django.db import models
from miscellaneous.models import Alias, Occupation

from tinymce.models import HTMLField


class AffiliateAlias(Alias):
    pass


class Affiliate(models.Model):
    name = models.CharField(max_length=100)
    aliases = models.ManyToManyField(AffiliateAlias, blank=True)
    occupation = models.ManyToManyField(Occupation, blank=True)
    date_of_birth = models.CharField(
        max_length=200, blank=True, help_text="format: MM/DD/YYYY multiple: MM/DD/YYYY - MM/DD/YYYY only year: YYYY")
    date_of_death = models.CharField(
        max_length=200, blank=True, help_text="format: MM/DD/YYYY multiple: MM/DD/YYYY - MM/DD/YYYY only year: YYYY")
    description = HTMLField(verbose_name='Description', null=True, blank=True)
    

    def __str__(self):
        return self.name
