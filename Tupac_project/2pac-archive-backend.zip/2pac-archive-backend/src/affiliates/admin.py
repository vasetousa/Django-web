from django import forms
from django.contrib import admin
from affiliates.models import Affiliate, AffiliateAlias

from miscellaneous.models import Occupation


class AffiliateAliasAdmin(admin.ModelAdmin):
    model = AffiliateAlias

    def has_module_permission(self, request):
        return False


class AffiliateAdminForm(forms.ModelForm):
    occupations = forms.ModelMultipleChoiceField(
        queryset=Occupation.objects.all().order_by('name'),
        widget=admin.widgets.FilteredSelectMultiple("Occupations", is_stacked=False),
        required=False
    )

    class Meta:
        model = Affiliate
        exclude = ('occupation',)


class AffiliateAdmin(admin.ModelAdmin):
    form = AffiliateAdminForm
    filter_horizontal = ('aliases',)


admin.site.register(AffiliateAlias, AffiliateAliasAdmin)
admin.site.register(Affiliate, AffiliateAdmin)
