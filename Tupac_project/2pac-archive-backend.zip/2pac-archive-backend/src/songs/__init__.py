default_app_config = 'songs.apps.SongsConfig'
