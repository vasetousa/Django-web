from django.db import models

from tinymce.models import HTMLField

from samples.models import Sample
from miscellaneous.models import AbstractLeakDate, AbstractMasteringDate, AbstractMixingDate, AbstractRecordingDate, Tag, AKA


class SongTag(Tag):
    pass


class SongAKA(AKA):
    pass


class Song(models.Model):
    def get_upload_path(instance, filename):
        return 'songs/{0}/artwork/{1}'.format(instance.song.title, filename)

    title = models.CharField(max_length=100)
    description = HTMLField(verbose_name='Description', null=True, blank=True)
    background = models.ImageField(
        null=True, blank=True, upload_to=get_upload_path)

    INCOMPLETE = '1'
    REVIEW = '2'
    COMPLETE = '3'
    FILL_STATUS = [
        (INCOMPLETE, 'Incomplete'),
        (REVIEW, 'Review'),
        (COMPLETE, 'Complete'),
    ]
    status = models.CharField(max_length=1, choices=FILL_STATUS,
        default=INCOMPLETE, help_text="The fill status")

    published = models.BooleanField(default=False)
    unleaked = models.BooleanField(default=False)
    no_feature = models.BooleanField(default=False, help_text="No 2Pac feature")
    tags = models.ManyToManyField(SongTag, blank=True)
    akas = models.ManyToManyField(SongAKA, blank=True)

    def __str__(self):
        return self.title


class RecordingDate(AbstractRecordingDate):
    pass


class Recording(models.Model):
    song = models.ForeignKey(Song, on_delete=models.SET_NULL, null=True)
    title = models.CharField(max_length=100)
    engineered_by = models.TextField(
        null=True, blank=True, help_text="Example: name1, name2, name3")
    dates_of_recording = models.ManyToManyField(RecordingDate, blank=True)
    recorded_at = models.CharField(max_length=200, blank=True)
    description = HTMLField(verbose_name='Description', null=True, blank=True)
    order = models.IntegerField(default=0)

    def __str__(self):
        if self.song:
            return '{0} - {1}'.format(self.song, self.title)

        return self.title


class Version(models.Model):
    song = models.ForeignKey(Song, on_delete=models.SET_NULL, null=True)
    title = models.CharField(max_length=100)
    date_of_creation = models.CharField(
        max_length=200, blank=True, help_text="format: MM/DD/YYYY multiple: MM/DD/YYYY - MM/DD/YYYY only year: YYYY")
    written_by = models.TextField(
        null=True, blank=True, help_text="Example: name1, name2, name3")
    produced_by = models.TextField(
        null=True, blank=True, help_text="Example: name1, name2, name3")
    instruments = models.TextField(null=True, blank=True)
    engineered_by = models.TextField(
        null=True, blank=True, help_text="Example: name1, name2, name3")
    description = HTMLField(verbose_name='Description', null=True, blank=True)
    recordings = models.ManyToManyField(Recording, blank=True)
    unleaked = models.BooleanField(default=False)
    no_feature = models.BooleanField(default=False, help_text="No 2Pac feature")
    order = models.IntegerField(default=0)

    def __str__(self):
        return self.title


class MixingDate(AbstractMixingDate):
    pass


class Mixdown(models.Model):
    version = models.ForeignKey(Version, on_delete=models.SET_NULL, null=True)
    title = models.CharField(max_length=100)
    performed_by = models.TextField(
        null=True, blank=True, help_text="Example: name1, name2, name3")
    mixed_by = models.TextField(
        null=True, blank=True, help_text="Example: name1, name2, name3")
    dates_of_mixing = models.ManyToManyField(MixingDate, blank=True)
    mixed_at = models.TextField(null=True, blank=True)
    description = HTMLField(verbose_name='Description', null=True, blank=True)
    lyrics = HTMLField(verbose_name='Lyrics', null=True, blank=True)
    samples = models.ManyToManyField(Sample, blank=True)
    unleaked = models.BooleanField(default=False)
    no_feature = models.BooleanField(default=False, help_text="No 2Pac feature")
    order = models.IntegerField(default=0)

    def __str__(self):
        return self.title


class MasteringDate(AbstractMasteringDate):
    pass


class LeakDate(AbstractLeakDate):
    pass


class Rip(models.Model):
    mixdown = models.ForeignKey(Mixdown, on_delete=models.SET_NULL, null=True)
    title = models.CharField(max_length=100)
    mastered_by = models.TextField(
        null=True, blank=True, help_text="Example: name1, name2, name3")
    dates_of_mastering = models.ManyToManyField(MasteringDate, blank=True)
    mastered_at = models.TextField(null=True, blank=True)
    track_duration = models.CharField(max_length=100, help_text="format: hh:mm:ss", null=True, blank=True)
    track_quality = models.CharField(max_length=100, null=True, blank=True)
    dates_leaked = models.ManyToManyField(LeakDate, blank=True)
    description = HTMLField(verbose_name='Description', null=True, blank=True)
    youtube_video = models.CharField(
        max_length=20, null=True, blank=True, help_text="ID of the youtube video (not url)")
    unleaked = models.BooleanField(default=False)
    no_feature = models.BooleanField(default=False, help_text="No 2Pac feature")
    order = models.IntegerField(default=0)

    def __str__(self):
        return self.title
