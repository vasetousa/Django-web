from graphene_django import DjangoObjectType
import graphene

from songs.models import Song, Version, Mixdown


class MixdownType(DjangoObjectType):
    class Meta:
        model = Mixdown


class VersionType(DjangoObjectType):
    class Meta:
        model = Version

    mixdowns = graphene.List(MixdownType)

    def resolve_mixdowns(self, info):
        return Mixdown.objects.filter(version__pk=self.pk)


class SongType(DjangoObjectType):
    class Meta:
        model = Song
        fields = ("id", "title", "description")
