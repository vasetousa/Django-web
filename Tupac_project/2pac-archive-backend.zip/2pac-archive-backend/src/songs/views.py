import json
from django.shortcuts import redirect
from django.http import HttpResponse

from tupac_api.settings import BASE_DIR

from .models import Song, Recording, Version, Mixdown


def import_songs(request):
    song_titles = []

    Song.objects.all().delete()

    with open(BASE_DIR + "/songs.txt", "r") as f:
        song_titles = f.read().splitlines()

    for title in song_titles:
        Song.objects.create(title=title.encode('utf-8').decode('utf-8'))

    return redirect('/admin/songs/song/')


def get_versions(request):
    id = request.GET.get('id', None)

    result = []
    if id is not None:
        result = list(Version.objects.filter(
            song_id=int(id)).values('id', 'title').order_by('title'))

    return HttpResponse(json.dumps(result), content_type="application/json")


def get_version_song(request):
    id = request.GET.get('id', None)

    result = []
    if id is not None:
        result = Version.objects.filter(pk=int(id))

    song_id = None
    if len(result) > 0 and result[0].song is not None:
        song_id = result[0].song.id

    return HttpResponse(json.dumps(song_id), content_type="application/json")


def get_mixdowns(request):
    id = request.GET.get('id', None)

    result = []
    if id is not None:
        result = list(Mixdown.objects.filter(
            version_id=int(id)).values('id', 'title').order_by('title'))

    return HttpResponse(json.dumps(result), content_type="application/json")


def get_mixdown_version_song(request):
    id = request.GET.get('id', None)

    result = []
    if id is not None:
        result = Mixdown.objects.filter(pk=int(id))

    song_id = None
    version_id = None
    if len(result) > 0:
        song_id = result[0].version.song.id
        version_id = result[0].version.id

    return HttpResponse(json.dumps({'songId': song_id, 'versionId': version_id}), content_type="application/json")
