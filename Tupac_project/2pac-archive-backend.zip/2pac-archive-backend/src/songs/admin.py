from django import forms
from django.contrib import admin

from .models import LeakDate, MasteringDate, MixingDate, RecordingDate, SongTag, SongAKA, Song, Recording, Version, Mixdown, Rip
from samples.models import Sample


class AdminSite(admin.AdminSite):
    def get_app_list(self, request):
        ordering = {
            "Songs": 1,
            "Recordings": 2,
            "Versions": 3,
            "Mixdowns": 4,
            "Rips": 5,
            "Song tags": 6,
        }

        # Get the registered apps
        app_dict = self._build_app_dict(request)

        # Sort the apps alphabetically.
        app_list = sorted(app_dict.values(), key=lambda x: x['name'].lower())

        # Sort the models alphabetically within the songs app.
        for app in app_list:
            if app['app_label'] == 'songs':
                app['models'].sort(key=lambda x: ordering[x['name']])

        return app_list


class SongTagAdmin(admin.ModelAdmin):
    model = SongTag

    def has_module_permission(self, request):
        return False


class SongAKAAdmin(admin.ModelAdmin):
    model = SongAKA

    def has_module_permission(self, request):
        return False


class SongAKAInline(admin.TabularInline):
    model = Song.akas.through
    extra = 1
    verbose_name = "Aka"
    verbose_name_plural = "Aka's"


class SongAdmin(admin.ModelAdmin):
    list_display = ('title', 'status', 'published')
    list_filter = ('status', 'published')
    search_fields = ['title']
    ordering = ('title',)
    filter_horizontal = ('tags',)
    exclude = ('akas',)
    inlines = [SongAKAInline]
    change_list_template = 'admin/songs/change_list.html'


class RecordingDateAdmin(admin.ModelAdmin):
    model = RecordingDate

    def has_module_permission(self, request):
        return False


class RecordingDateInline(admin.TabularInline):
    model = Recording.dates_of_recording.through
    extra = 1
    verbose_name = "Recording date"
    verbose_name_plural = "Recording dates"


class RecordingAdmin(admin.ModelAdmin):
    list_display = ('__str__',)
    search_fields = ['title']
    ordering = ('title',)
    exclude = ('dates_of_recording',)
    inlines = [RecordingDateInline]


class VersionAdminForm(forms.ModelForm):
    recordings = forms.ModelMultipleChoiceField(
        queryset=Recording.objects.all().order_by('title'),
        widget=admin.widgets.FilteredSelectMultiple("Recordings", is_stacked=False),
        required=False
    )

    class Meta:
        model = Version
        fields = ('song', 'title', 'date_of_creation', 'written_by', 'produced_by', 'instruments',
                  'engineered_by', 'description', 'unleaked', 'no_feature', 'order')


class VersionAdmin(admin.ModelAdmin):
    list_display = ('song', 'get_version',)
    search_fields = ['song__title']
    ordering = ('song__title',)
    form = VersionAdminForm

    def get_version(self, obj):
        return obj.title
    get_version.short_description = 'Version'


class MixingDateAdmin(admin.ModelAdmin):
    model = MixingDate

    def has_module_permission(self, request):
        return False


class MixingDateInline(admin.TabularInline):
    model = Mixdown.dates_of_mixing.through
    extra = 1
    verbose_name = "Mixing date"
    verbose_name_plural = "Mixing dates"


class MixdownAdminForm(forms.ModelForm):
    song = forms.ModelChoiceField(
        queryset=Song.objects.all().order_by('title'))
    samples = forms.ModelMultipleChoiceField(
        queryset=Sample.objects.all().order_by('title'),
        widget=admin.widgets.FilteredSelectMultiple("Samples", is_stacked=False),
        required=False
    )

    class Meta:
        model = Mixdown
        fields = ('song', 'version', 'title', 'performed_by', 'mixed_by',
                  'mixed_at', 'description', 'lyrics', 'samples', 'unleaked', 'no_feature', 'order')


class MixdownAdmin(admin.ModelAdmin):
    list_display = ('get_song', 'version', 'get_mixdown',)
    search_fields = ['version__song__title']
    ordering = ('version__song__title',)
    form = MixdownAdminForm
    exclude = ('dates_of_mixing',)
    inlines = [MixingDateInline,]

    def get_song(self, obj):
        if obj.version and obj.version.song:
            return obj.version.song

        return None
    get_song.short_description = 'Song'

    def get_mixdown(self, obj):
        return obj.title
    get_mixdown.short_description = 'Mixdown'


class RipAdminForm(forms.ModelForm):
    song = forms.ModelChoiceField(
        queryset=Song.objects.all().order_by('title'))
    version = forms.ModelChoiceField(
        queryset=Version.objects.all().order_by('title'))

    class Meta:
        model = Rip
        fields = ('song', 'version', 'mixdown', 'title', 'mastered_by', 'mastered_at',
        'track_duration', 'track_quality', 'description', 'youtube_video', 'unleaked', 'no_feature', 'order')


class MasteringDateAdmin(admin.ModelAdmin):
    model = MasteringDate

    def has_module_permission(self, request):
        return False


class MasteringDateInline(admin.TabularInline):
    model = Rip.dates_of_mastering.through
    extra = 1
    verbose_name = "Mastering date"
    verbose_name_plural = "Mastering dates"


class LeakDateAdmin(admin.ModelAdmin):
    model = LeakDate

    def has_module_permission(self, request):
        return False


class LeakDateInline(admin.TabularInline):
    model = Rip.dates_leaked.through
    extra = 1
    verbose_name = "Leak date"
    verbose_name_plural = "Leak dates"


class RipAdmin(admin.ModelAdmin):
    list_display = ('get_song', 'get_version', 'get_mixdown', 'get_title')
    search_fields = ['mixdown__version__song__title']
    ordering = ('mixdown__version__song__title',)
    form = RipAdminForm
    exclude = ('dates_of_mastering', 'dates_of_leak',)
    inlines = [MasteringDateInline, LeakDateInline,]

    def get_song(self, obj):
        return obj.mixdown.version.song
    get_song.short_description = 'Song'

    def get_version(self, obj):
        return obj.mixdown.version
    get_version.short_description = 'Version'

    def get_mixdown(self, obj):
        return obj.mixdown
    get_mixdown.short_description = 'Mixdown'

    def get_title(self, obj):
        return obj.title
    get_title.short_description = 'Rip'


admin.site.register(SongTag, SongTagAdmin)
admin.site.register(SongAKA, SongAKAAdmin)
admin.site.register(Song, SongAdmin)

admin.site.register(RecordingDate, RecordingDateAdmin)
admin.site.register(Recording, RecordingAdmin)

admin.site.register(Version, VersionAdmin)

admin.site.register(MixingDate, MixingDateAdmin)
admin.site.register(Mixdown, MixdownAdmin)

admin.site.register(MasteringDate, MasteringDateAdmin)
admin.site.register(LeakDate, LeakDateAdmin)
admin.site.register(Rip, RipAdmin)

admin.AdminSite.get_app_list = AdminSite.get_app_list
