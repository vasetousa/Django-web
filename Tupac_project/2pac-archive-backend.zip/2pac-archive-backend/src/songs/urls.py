from .views import import_songs, get_versions, get_version_song, get_mixdowns, get_mixdown_version_song
from django.urls import path

urlpatterns = [
    path('import_songs/', import_songs, name="import_songs"),
    path('get_versions/', get_versions, name="get_versions"),
    path('get_version_song/', get_version_song, name="get_version_song"),
    path('get_mixdowns/', get_mixdowns, name="get_mixdowns"),
    path('get_mixdown_version_song/', get_mixdown_version_song, name="get_mixdown_version_song"),
]
