from django.db import models

from tinymce.models import HTMLField


class Occupation(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Tag(models.Model):
    name = models.CharField(max_length=200)

    def __str__(self):
        return self.name


class AKA(models.Model):
    name = models.CharField(max_length=255)
    is_bootleg = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class Alias(models.Model):
    name = models.CharField(max_length=255)

    def __str__(self):
        return self.name


class AbstractRecordingDate(models.Model):
    date_of_recording = models.CharField(
        max_length=200, blank=True, help_text="format: MM/DD/YYYY multiple: MM/DD/YYYY - MM/DD/YYYY only year: YYYY")
    explanation = HTMLField(verbose_name='Explanation', null=True, blank=True)

    class Meta:
        abstract = True

    def __str__(self):
        return self.date_of_recording


class AbstractMixingDate(models.Model):
    date_of_mixing = models.CharField(
        max_length=200, blank=True, help_text="format: MM/DD/YYYY multiple: MM/DD/YYYY - MM/DD/YYYY only year: YYYY")
    explanation = HTMLField(verbose_name='Explanation', null=True, blank=True)

    class Meta:
        abstract = True

    def __str__(self):
        return self.date_of_mixing


class AbstractMasteringDate(models.Model):
    date_of_mastering = models.CharField(
        max_length=200, blank=True, help_text="format: MM/DD/YYYY multiple: MM/DD/YYYY - MM/DD/YYYY only year: YYYY")
    explanation = HTMLField(verbose_name='Explanation', null=True, blank=True)

    class Meta:
        abstract = True

    def __str__(self):
        return self.date_of_mastering


class AbstractLeakDate(models.Model):
    date_leaked = models.CharField(
        max_length=200, blank=True, help_text="format: MM/DD/YYYY multiple: MM/DD/YYYY - MM/DD/YYYY only year: YYYY")
    explanation = HTMLField(verbose_name='Explanation', null=True, blank=True)

    class Meta:
        abstract = True

    def __str__(self):
        return self.date_leaked
