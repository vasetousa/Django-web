from django.contrib import admin

from miscellaneous.models import Occupation


class OccupationAdmin(admin.ModelAdmin):
    pass


admin.site.register(Occupation, OccupationAdmin)
