from django.apps import AppConfig


class MiscellaneousConfig(AppConfig):
    name = 'miscellaneous'
