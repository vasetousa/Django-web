from django.db import models

from tinymce.models import HTMLField

from languages.fields import LanguageField


class AbstractArticle(models.Model):
    issue = models.CharField(max_length=300, null=True, blank=True)
    date = models.CharField(
        max_length=200, blank=True, help_text="format: MM/DD/YYYY multiple: MM/DD/YYYY - MM/DD/YYYY only year: YYYY no day: MM/##/YYYY no month: ##/DD/YYYY")
    description = HTMLField(verbose_name='Description', null=True, blank=True)
    language = LanguageField(max_length=300, null=True, blank=True)

    class Meta:
        abstract = True


class Article(AbstractArticle):
    magazine = models.CharField(max_length=300, null=True, blank=True)

    def __str__(self):
        if not self.magazine:
            return ''

        return self.magazine


class Magazine(AbstractArticle):
    magazine = models.CharField(max_length=300, null=True, blank=True)

    def __str__(self):
        if not self.magazine:
            return ''

        return self.magazine


class Newspaper(AbstractArticle):
    newspaper = models.CharField(max_length=300, null=True, blank=True)

    def __str__(self):
        if not self.newspaper:
            return ''

        return self.newspaper


class PromoAdd(AbstractArticle):
    promo_add = models.CharField(max_length=300, null=True, blank=True)

    def __str__(self):
        if not self.promo_add:
            return ''

        return self.promo_add


class TupacChart(AbstractArticle):
    chart = models.CharField(max_length=300, null=True, blank=True)

    def __str__(self):
        if not self.chart:
            return ''

        return self.chart


class ArticleScan(models.Model):
    def get_upload_path(instance, filename):
        return 'written_sources/{0}'.format(filename)

    image = models.ImageField(
        null=True, blank=True, upload_to=get_upload_path)
    article = models.ForeignKey(Article, on_delete=models.CASCADE, null=True, related_name="article_scans")
    magazine = models.ForeignKey(Magazine, on_delete=models.CASCADE, null=True, related_name="magazine_scans")
    newspaper = models.ForeignKey(Newspaper, on_delete=models.CASCADE, null=True, related_name="newspaper_scans")
    promo_add = models.ForeignKey(PromoAdd, on_delete=models.CASCADE, null=True, related_name="promo_add_scans")
    tupac_chart = models.ForeignKey(TupacChart, on_delete=models.CASCADE, null=True, related_name="tupac_chart_scans")
