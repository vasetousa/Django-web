from django.apps import AppConfig


class WrittenSourcesConfig(AppConfig):
    name = 'written_sources'
    verbose_name = 'Written Sources'
