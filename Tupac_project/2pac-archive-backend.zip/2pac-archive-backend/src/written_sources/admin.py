from django.contrib import admin

from rangefilter.filters import DateRangeFilter

from written_sources.models import ArticleScan, Article, Magazine, Newspaper, PromoAdd, TupacChart


class ArticleScanInline(admin.StackedInline):
    model = ArticleScan
    extra = 0
    exclude = ["magazine", "newspaper", "promo_add", "tupac_chart"]


class MagazineScanInline(admin.StackedInline):
    model = ArticleScan
    extra = 0
    exclude = ["article", "newspaper", "promo_add", "tupac_chart"]


class NewspaperScanInline(admin.StackedInline):
    model = ArticleScan
    extra = 0
    exclude = ["article", "magazine", "promo_add", "tupac_chart"]


class PromoAddScanInline(admin.StackedInline):
    model = ArticleScan
    extra = 0
    exclude = ["article", "magazine", "newspaper", "tupac_chart"]


class TupacChartScanInline(admin.StackedInline):
    model = ArticleScan
    extra = 0
    exclude = ["article", "magazine", "newspaper", "promo_add"]


class ArticleAdmin(admin.ModelAdmin):
    fields = ('magazine', 'issue', 'date', 'description', 'language',)
    list_display = ('magazine', 'date',)
    list_filter = (('date', DateRangeFilter),)
    inlines = [
        ArticleScanInline,
    ]


class MagazineAdmin(admin.ModelAdmin):
    fields = ('magazine', 'issue', 'date', 'description', 'language',)
    list_display = ('magazine', 'date',)
    list_filter = (('date', DateRangeFilter),)
    inlines = [
        MagazineScanInline,
    ]


class NewspaperAdmin(admin.ModelAdmin):
    fields = ('newspaper', 'issue', 'date', 'description', 'language',)
    list_display = ('newspaper', 'date',)
    list_filter = (('date', DateRangeFilter),)
    inlines = [
        NewspaperScanInline,
    ]


class PromoAddAdmin(admin.ModelAdmin):
    fields = ('promo_add', 'issue', 'date', 'description', 'language',)
    list_display = ('promo_add', 'date',)
    list_filter = (('date', DateRangeFilter),)
    inlines = [
        PromoAddScanInline,
    ]


class TupacChartAdmin(admin.ModelAdmin):
    fields = ('chart', 'issue', 'date', 'description', 'language',)
    list_display = ('chart', 'date',)
    list_filter = (('date', DateRangeFilter),)
    inlines = [
        TupacChartScanInline,
    ]


admin.site.register(Article, ArticleAdmin)
admin.site.register(Magazine, MagazineAdmin)
admin.site.register(Newspaper, NewspaperAdmin)
admin.site.register(PromoAdd, PromoAddAdmin)
admin.site.register(TupacChart, TupacChartAdmin)
