from django.apps import AppConfig


class TupacApiConfig(AppConfig):
    name = 'tupac_api'
    verbose_name = "2Pac API"
