import graphene

from songs.models import Song, Version, Mixdown
from songs.graphql.types import SongType, VersionType, MixdownType


class Query(graphene.ObjectType):
    all_songs = graphene.List(graphene.NonNull(SongType), required=True)
    song = graphene.Field(SongType, id=graphene.Int())

    def resolve_all_songs(self, info):
        return Song.objects.filter(published=True).order_by('title')

    def resolve_song(self, info, id):
        return Song.objects.get(pk=id)


schema = graphene.Schema(query=Query)
