from django.contrib import admin
from django.urls import include, path
from django.conf.urls.static import static
from django.conf import settings
from graphene_django.views import GraphQLView
from django.views.decorators.csrf import csrf_exempt

from .settings import DEBUG

urlpatterns = [
    path('admin/', admin.site.urls),
    path('admin/songs/', include('songs.urls')),
    path('graphql', csrf_exempt(GraphQLView.as_view(graphiql=DEBUG))),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

admin.site.site_header = 'The 2Pac Archive'
admin.site.site_title = 'The 2Pac Archive'
admin.site.index_title = "Welcome to the 2Pac Archive"
