default_app_config = 'tupac_api.apps.TupacApiConfig'
